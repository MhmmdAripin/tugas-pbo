<?php
    $config['base_url'] = 'http://192.168.43.225/TUGAS_PBO_XIIRPL1/';
?>